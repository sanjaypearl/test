import { v2 as cloudinary } from "cloudinary";
import dotenv from "dotenv";
dotenv.config();

// Configure Cloudinary using environment variables
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// ✅ Upload function: handles both file object or file path
// export const uploadFileToCloudinary = async (files, folderName = "default") => {
//   try {
//     // const fileArray = Array.isArray(files) ? files : [files];

//     // const uploadPromises = fileArray.map((file) => {
//     //   const filePath = typeof file === "string" ? file : file.path;

//     //   if (!filePath) {
//     //     throw new Error("Missing file path");
//     //   }

//     //   return cloudinary.uploader.upload(filePath, {
//     //     folder: `Enquiry-Website/${folderName}`,
//     //   });
//     // });

//     // const uploadResults = await Promise.all(uploadPromises);

//     // return uploadResults.map((result) => ({
//     //   secure_url: result.secure_url,
//     //   public_id: result.public_id,
//     // }));
//     const result = await cloudinary.uploader.upload(filePath, {
//       folder: `Enquiry-Website/${folderName}`,
//       resource_type: "auto",
//       // optionally: public_id: path.basename(filePath) to preserve extension
//     });
//     return [{ secure_url: result.secure_url, public_id: result.public_id }];
//   } catch (error) {
//     throw new Error(`File upload failed: ${error.message}`);
//   }
// };

export const uploadFileToCloudinary = async (files, folderName = "default") => {
  try {
    const fileArray = Array.isArray(files) ? files : [files];

    const uploadPromises = fileArray.map((file) => {
      const filePath = typeof file === "string" ? file : file.path;

      if (!filePath) {
        throw new Error("Missing file path");
      }

      return cloudinary.uploader.upload(filePath, {
        folder: `Enquiry-Website/${folderName}`,
        resource_type: "auto", // automatically detects image, video, raw, etc.
      });
    });

    const uploadResults = await Promise.all(uploadPromises);

    return uploadResults.map((result) => ({
      secure_url: result.secure_url,
      public_id: result.public_id,
    }));
  } catch (error) {
    throw new Error(`File upload failed: ${error.message}`);
  }
};

// ✅ Delete Cloudinary files by public_id(s)
export const deleteFileFromCloudinary = async (files) => {
  const publicIds = Array.isArray(files)
    ? files.map((file) => file.public_id)
    : [files.public_id];

  try {
    const deleteResults = await Promise.all(
      publicIds.map(async (publicId) => {
        try {
          const result = await cloudinary.uploader.destroy(publicId);
          return { publicId, result };
        } catch (error) {
          return { publicId, error: error.message || "Deletion failed" };
        }
      })
    );

    const failedDeletes = deleteResults.filter((res) => res.error);
    if (failedDeletes.length > 0) {
      return {
        success: false,
        message: "Some files failed to delete",
        failedDeletes,
      };
    }

    return { success: true, result: deleteResults };
  } catch (error) {
    return {
      success: false,
      message: "Error during Cloudinary deletion",
      error: error.message,
    };
  }
};

// import { v2 as cloudinary } from "cloudinary";
// import dotenv from "dotenv";
// dotenv.config();

// cloudinary.config({
//   cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
//   api_key: process.env.CLOUDINARY_API_KEY,
//   api_secret: process.env.CLOUDINARY_API_SECRET,
// });

// export const uploadFileToCloudinary = async (filePath, folderName = "Reports") => {
//   try {
//     const result = await cloudinary.uploader.upload(filePath, {
//       folder: `Enquiry-Website/${folderName}`,
//       resource_type: "auto",
//       // optionally: public_id: path.basename(filePath) to preserve extension
//     });
//     return [{ secure_url: result.secure_url, public_id: result.public_id }];
//   } catch (err) {
//     throw new Error(`Cloud upload failed: ${err.message}`);
//   }
// };

// export const deleteFileFromCloudinary = async (public_idList) => {
//   const results = await Promise.all(
//     public_idList.map(async (public_id) => cloudinary.uploader.destroy(public_id, { resource_type: "auto" }))
//   );
//   return results;
// };
