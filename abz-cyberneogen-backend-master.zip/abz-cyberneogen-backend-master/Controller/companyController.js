import Company from "../Model/company.js";
import { User } from "../Model/user.js";
import { hashPassword, comparePassword } from '../config/bcrpt.js';
import { uploadFileToCloudinary, deleteFileFromCloudinary } from "../config/cloudinary.js";
import fs from 'fs';

export const createCompany = async (req, res) => {
  try {
    const { name, email, industry, status,password } = req.body;
    if (!name || !email || !industry ) {
      return res.status(400).json({ success: false, message: "All fields are required." });
    }
    const hashedPassword = await hashPassword(password);

    const company = new Company({
      name:name,
      email,
      industry,
      status,
      password:hashedPassword
    });

    if (req.file) {
      const uploadResult = await uploadFileToCloudinary(req.file, "company_logos");
      company.logoUrl = uploadResult[0].secure_url;
      company.logoPublicId = uploadResult[0].public_id;

      fs.unlinkSync(req.file.path);
    }

    await company.save();
    res.status(201).json({ success: true, data: company });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};


export const updateCompany = async (req, res) => {
  try {
    const {
      name,
      email,
      website,
      industry,
      location,
      foundedYear,
      employeeSize,
      status,
      companyDescription
    } = req.body;

    const { _id } = req.params;

    let companySettings = await User.findById(_id);
    if (!companySettings) {
      return res.status(404).json({
        success: false,
        message: 'Company profile not found',
      });
    }

    // Update text fields
    companySettings.name = name || companySettings.name;
    companySettings.email = email || companySettings.email;
    companySettings.status = status || companySettings.status;
    companySettings.website = website || companySettings.website;
    companySettings.industry = industry || companySettings.industry;
    companySettings.location = location || companySettings.location;
    companySettings.foundedYear = foundedYear || companySettings.foundedYear;
    companySettings.employeeSize = employeeSize || companySettings.employeeSize;
    companySettings.companyDescription = companyDescription || companySettings.companyDescription;

    // If logo image is uploaded
    if (req.file) {
      const uploadResult = await uploadFileToCloudinary(req.file, "company_logos");
      companySettings.logoUrl = uploadResult[0].secure_url;
      companySettings.logoPublicId = uploadResult[0].public_id;

      fs.unlinkSync(req.file.path);
    }

    await companySettings.save();

    res.status(200).json({
      success: true,
      message: 'Company profile updated successfully',
      data: companySettings
    });

  } catch (err) {
    console.error('Update company error:', err);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error',
      error: err.message
    });
  }
};

// export const getAllCompanies = async (req, res) => {
//   try {
//     const companies = await Company.find().sort({ createdAt: -1 }).select('-password');
//     const totalCompany = await Company.countDocuments();
//     if (!companies || companies.length === 0) {
//       return res.status(404).json({ success: false, message: 'No companies found' })
//     }
//     res.status(200).json({ success: true, message: "Companies Get Successfully", data: companies, totalCompany });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };


export const getCompanyById = async (req, res) => {
  try {
    const company = await Company.findById(req.params.id).select('-password');
    if (!company) {
      return res.status(404).json({ success: false, message: 'Company not found' });
    }
    res.status(200).json({ success: true, data: company });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


// Delete company
export const deleteCompany = async (req, res) => {
  try {
    const { _id } = req.params;
    const deleted = await Company.findByIdAndDelete(_id);
    if (deleted.logoPublicId) {
      await deleteFileFromCloudinary({ public_id: deleted.logoPublicId });
    }
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Company not found' });
    }
    res.status(200).json({ success: true, message: 'Company deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};




