import { User } from "../Model/user.js";
import { Researcher } from "../Model/researcher.js";
import { uploadFileToCloudinary, deleteFileFromCloudinary } from "../config/cloudinary.js";
import fs from 'fs';

// ✅ Update researcher profile with Cloudinary support
export const updateResearcher = async (req, res) => {
  try {
    const { user } = req.params;

    const {
      name,
      username,
      bio,
      phone,
      country,
      timeZone,
      language,
      specializations,
      skills,
      topOwasp,
      paymentMethod,
      paypalEmail,
      taxInfo,
      taxStatus,
      certifications
    } = req.body;

    let researcher = await Researcher.findOne({ user });

    if (!researcher) {
      return res.status(404).json({
        success: false,
        message: "Researcher Profile Not Found"
      });
    }

    researcher.username = username || researcher.username;
    researcher.name = name || researcher.name;
    researcher.bio = bio || researcher.bio;
    researcher.phone = phone || researcher.phone;
    researcher.country = country || researcher.country;
    researcher.timeZone = timeZone || researcher.timeZone;
    researcher.language = language || researcher.language;
    researcher.specializations = specializations || researcher.specializations;
    researcher.skills = skills || researcher.skills;
    researcher.topOwasp = topOwasp || researcher.topOwasp;
    researcher.paymentMethod = paymentMethod || researcher.paymentMethod;
    researcher.paypalEmail = paypalEmail || researcher.paypalEmail;
    researcher.taxInfo = taxInfo || researcher.taxInfo;
    researcher.taxStatus = taxStatus || researcher.taxStatus;
    researcher.certifications = certifications || researcher.certifications;


    if (req.file) {
      const uploadResult = await uploadFileToCloudinary(req.file, "researcher_logos");
      researcher.logoUrl = uploadResult[0].secure_url;
      researcher.logoPublicId = uploadResult[0].public_id;

      fs.unlinkSync(req.file.path);
    }

    await researcher.save();

    res.status(200).json({
      success: true,
      message: "Researcher profile updated successfully",
      data: researcher,
    });

  } catch (err) {
    console.error("Update error:", err);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: err.message
    });
  }
};

// ✅ Delete researcher
export const deleteResearch = async (req, res) => {
  try {
    const { _id } = req.params;

    const deleted = await Researcher.findByIdAndDelete(_id); // FIXED

    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Researcher not found' });
    }

    // Optional: delete profile picture from Cloudinary
    if (deleted.profilePicture && deleted.profilePicture.public_id) {
      await deleteFileFromCloudinary(deleted.profilePicture.public_id);
    }

    res.status(200).json({ success: true, message: 'Researcher deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const getAllResearcher = async(req,res)=>{
  try {
    const getResearch = await Researcher.find().select('-password')
    if(!getResearch){
      res.status(404).json({
        success:false,
        message:"Researcher Not Found"
      })
    }
    res.status(200).json({
      success:true,
      message:"Get All Researcher Successfully",
      data:getResearch
    })
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
