import Treasurer from "../Model/treasurer.js";
import { hashPassword } from '../config/bcrpt.js';
import { uploadFileToCloudinary, deleteFileFromCloudinary } from "../config/cloudinary.js";

export const addTreasurer = async (req, res) => {
    try {
        const { name, email, phone, role, password } = req.body;
        const existEmail = await Treasurer.findOne({ email: email })
        if (existEmail) {
            res.status(403).json({
                success: true,
                message: ` this email:${email} already Exist!..`,
            })
        }
        const hashedPassword = await hashPassword(password)
        const treasurerData = await Treasurer({
            name: name,
            email: email,
            password: hashedPassword,
            role: role,
            phone: phone
        })
        await treasurerData.save()
        res.status(200).json({
            success: true,
            message: "Treasurer Is Created Successfully",
            data: treasurerData
        })
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Internal Server Error",
            data: null
        })
    }
}

export const getAllTreasurer = async (req, res) => {
    try {
        const treData = await Treasurer.find().select('-password')
        if (!treData) {
            res.status(404).json({
                success: false,
                message: "Treasurer Not Found!"
            })
        }
        res.status(200).json({
            success: true,
            message: "Get All Treasurer Successfully!",
            data: treData
        })

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Internal Server Error',
            data: null
        })

    }
}

export const TreaDataById = async (req, res) => {
    try {
        const { _id } = req.params
        const treData = await Treasurer.findById(_id).select('-password')
        if (!treData) {
            res.status(404).json({
                success: false,
                message: "Treasurer Is Not Found!"
            })
        }
        res.status(200).json({
            success: true,
            message: "Get Treasurer ById Successfully!",
            data: treData
        })

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Internal Server Error",
            data: null
        })
    }
}

export const updateTreasurer = async (req, res) => {
    try {
        const { _id } = req.params;
        const { name, phone, email, role, verifiedByAdmin, status } = req.body;
        const existTre = await Treasurer.findById(_id)
        if (!existTre) {
            res.status(404).json({
                success: false,
                message: "Treasurer Not Found!..."
            })
        }
        if (name) existTre.name = name;
        if (email) existTre.email = email;
        if (phone) existTre.phone = phone;
        if (role) existTre.role = role;
        if (verifiedByAdmin) existTre.verifiedByAdmin = verifiedByAdmin;
        if (status) existTre.status = status;
        if (req.file) {
            const uploadedImage = await uploadFileToCloudinary(req.file, 'treasurerImg')
            existTre.logoUrl = uploadedImage[0].secure_url;
            existTre.logoPublicId = uploadedImage[0].public_id;
        }
        await existTre.save()
        res.status(200).json({
            success:true,
            message:"Teasurer Is Updated Successfully!",
            data:existTre
        })
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Internal Server Error",
            data: null
        })
    }
}

export const treDelete = async(req,res)=>{
    try {
        const {_id}=req.params;
        const TreExist = await Treasurer.findByIdAndDelete(_id)
        if(!TreExist){
            res.status(404).json({
                success:false,
                message:"Treasurer Is Not Found",
            })
        }
        res.status(200).json({
            success:true,
            message:"Treausrer Deleted Successully!..",
            data:TreExist
        })
        
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Internal Server Error",
            data: null
        })
    }
}