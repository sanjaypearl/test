import { KYCModel } from '../Model/userKYC.js';

export const KYC = async (req, res) => {
  try {
    const { aadhaarNumber, panNumber ,userId} = req.body;
    // const userId = req.user.id;

    if (!aadhaarNumber || !panNumber ||!userId) {
      return res.status(400).json({
        success: false,
        message: 'Both Aadhaar number or id and PAN number are required',
      });
    }
    const aadhaarRegex = /^\d{12}$/;
    if (!aadhaarRegex.test(aadhaarNumber)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Aadhaar number. It must be exactly 12 digits',
      });
    }

    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    if (!panRegex.test(panNumber)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid PAN number. Format should be like ABCDE1234F',
      });
    }

    const existing = await KYCModel.findOne({ userId });
    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'KYC already submitted for this user',
      });
    }

    const kyc = await KYCModel.create({
      userId,
      aadhaarNumber,
      panNumber,
    });

    res.status(200).json({
      success: true,
      message: 'KYC submitted successfully',
      data: kyc,
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server error while submitting KYC',
    });
  }
};
