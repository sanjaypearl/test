import express from "express";
import { upload } from "../middleware/multer.js";
import {updateResearcher, deleteResearch ,getAllResearcher} from "../Controller/researcherContrroleer.js"


const router = express.Router();

// PUT /api/researchers/update/:id
// router.put("/updateResearcher/:_id", upload.single("profilePicture"), updateResearcher);
router.delete("/researchDeleted/:_id",deleteResearch)
router.put("/updateResearcher/:_id",upload.single('logoUrl') ,updateResearcher)
router.get("/getAllResearcher",getAllResearcher)

export default router;
