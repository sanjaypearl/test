import express from 'express';
import { contactUs,getAllContacts} from '../Controller/contactController.js';

const router = express.Router();

router.post('/contactUs',contactUs );
router.get('/getAllContacts', getAllContacts);

export default router;
