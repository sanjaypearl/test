import express from 'express';
import * as userKYC from '../Controller/userKYC.js';

const router = express.Router();


router.post('/KYC', userKYC.KYC );



export default router;
