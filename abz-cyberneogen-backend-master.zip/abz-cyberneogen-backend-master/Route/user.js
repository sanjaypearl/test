import express from 'express';
import * as userController from '../Controller/userController.js';
import {upload} from '../middleware/multer.js';
import {protect,adminOnly} from '../middleware/isAdmin.js.js';

const router = express.Router();

// All routes below require login
// router.use(protect);


router.post('/register', userController.registerUser);
router.post('/login', userController.login);
// router.get('/getAllUsers', userController.getAllUsers);
router.get('/getAllUsers', userController.getAllUsers);
// router.get('/getAllUsers',protect,adminOnly, userController.getAllUsers);
router.get('/getUserById/:id', userController.getUserById);         
// router.get('/getUserById/:id',protect,adminOnly, userController.getUserById);         
router.put('/updateUserProfile/:_id',upload.single('profilePicture'), userController.updateUserProfile);          
// router.put('/updateUserProfile/:_id',protect,adminOnly,upload.single('profilePicture'), userController.updateUserProfile);          
router.delete('/deleteUser/:_id', userController.deleteUser);
// router.delete('/deleteUser/:_id',protect,adminOnly, userController.deleteUser);
router.post('/change-password/:id',protect,adminOnly, userController.changePassword);
router.get('/getAllControlOnAdminSide', userController.getAllControlOnAdminSide);
router.get('/getAllCompanies', userController.getAllCompanies);
router.get('/getTotalCounts', userController.getTotalCounts);


export default router;
