 
import express from 'express';
import {
  createProgram,
  getPrograms,
  getProgramById,
  updateProgram,
  getAllActiveProgram,
  deleteProgram
//   deleteProgram,
} from '../Controller/programController.js';
import {upload} from '../middleware/multer.js'

const router = express.Router();

router.post('/createProgram',upload.single("logoUrl") ,createProgram);
router.get('/getPrograms', getPrograms);
router.get('/getProgramById/:_id', getProgramById);
router.put('/updateProgram/:_id',upload.single("logoUrl"), updateProgram);
router.get('/getAllActiveProgram', getAllActiveProgram);
router.delete('/deleteProgram/:_id', deleteProgram);

export default router;
