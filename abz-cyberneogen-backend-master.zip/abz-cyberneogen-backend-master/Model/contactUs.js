import mongoose from 'mongoose';

const contactUsSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      trim: true,
      lowercase: true,
      match: [/.+\@.+\..+/, 'Please fill a valid email address'],
    },
    subject: {
      type: String,
    }
    
  },
  { timestamps: true }
);

const Contact = mongoose.model('ContactUs', contactUsSchema);

export default Contact;
