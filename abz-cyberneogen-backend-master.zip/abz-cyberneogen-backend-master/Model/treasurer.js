import mongoose from 'mongoose';

const treasurerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },

  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
  },

  password: {
    type: String,
    required: true,
    minlength: 6,
  },

  phone: {
    type: String,
  },

  role: {
    type: String,
    default: 'treasurer',
    enum: ['treasurer'],
  },

  logoUrl: {
    type: String,
  },

  status: {
    type:String,
    enum:['active','inactive'],
    default: 'inactive',
  },

  verifiedByAdmin: {
    type: Boolean,
    default: false,
  },

}, { timestamps: true });


const Treasurer = mongoose.model('Treasurer', treasurerSchema);
export default Treasurer;
