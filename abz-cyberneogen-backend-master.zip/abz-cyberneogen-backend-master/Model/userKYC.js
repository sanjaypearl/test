import mongoose from 'mongoose';

const kycSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  aadhaarNumber: { type: String, required: true },
  panNumber: { type: String, required: true }
});

export const KYCModel = mongoose.model('KYC', kycSchema);
