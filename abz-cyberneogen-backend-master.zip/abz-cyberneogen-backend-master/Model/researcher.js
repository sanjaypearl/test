import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    },
    name: {
      type: String,
      trim: true,
      minlength: 2,
      maxlength: 50,
    },
    email: {
      type: String,
      unique: true,
      trim: true,
      lowercase: true,
      match: [
        /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
        'Please enter a valid email address',
      ],
    },
    password: {
      type: String,
      minlength: 6,
    },
     logoUrl: {
      type: String,
    },
    // username: {
    //   type: String,
    //   unique: true,
    //   trim: true,
    // },
    // profilePicture: {
    //   type: String,
    //   default: '',
    // },
    // bio: {
    //   type: String,
    //   maxlength: 500,
    // },

    // phone: {
    //   type: String,
    // },
     role: {
      type: String,
      enum: ['researcher'],
      default: 'researcher',
    },
    // country: {
    //   type: String,
    // },
    // timeZone: {
    //   type: String,
    // },
    // language: {
    //   type: String,
    //   default: 'English',
    // },

    // Researcher Profile
    specializations: [String], // e.g. Web Apps, APIs
    skills: [String],          // e.g. Python, Burp Suite, JavaScript
    topOwasp: [String],        // e.g. OWASP Top 10

    certifications: [
      {
        name: String,
        issuer: String,
        year: String,
      }
    ],

    // Payment Information
    paymentMethod: {
      type: String, // e.g. PayPal
    },
    paypalEmail: {
      type: String,
      lowercase: true,
    },
    taxInfo: {
      type: String, // e.g. "W9 (US Taxpayer)"
    },
    taxStatus: {
      type: String, // e.g. "Submitted and verified"
    }
  },
  {
    timestamps: true,
  }
);

export const Researcher = mongoose.model('Researcher', userSchema);
