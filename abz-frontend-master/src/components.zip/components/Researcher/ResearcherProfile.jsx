import React from "react";

const ResearcherProfile = () => {
  return <div>ResearcherProfile</div>;
};

export default ResearcherProfile;
